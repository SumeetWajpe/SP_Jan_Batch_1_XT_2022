const express = require("express");
const path = require("path");
const app = express();
let courses = require("./models/courses.model");
var cors = require("cors");
const port = 3000;

app.use(cors());
app.use(express.static(path.join(__dirname, "static")));
app.use(express.json());
// app.get("/", (req, res) => {
//   //   res.send("<h1>Hello World!</h1>");
//   res.sendFile("Index.html", { root: __dirname });
// });

app.get("/courses", (req, res) => {
  // would be fetched from DB !

  res.json(courses);
});

app.delete("/courses/:id", (req, res) => {
  // console.log("Deleting", req.params.id);
  // courses  -> find the item by id & delete it
  var theId = +req.params.id; // convert to number

  let theIndex = courses.findIndex((course) => course.id === theId);
  courses.splice(theIndex, 1);
  res.json({ msg: "Success" });
});

app.post("/newcourse", (req, res) => {
  let newCourse = req.body;
  courses.push(newCourse);

  // immutability
  // courses = [...courses,newCourse]
  res.json({ msg: "Success" });
});
app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
