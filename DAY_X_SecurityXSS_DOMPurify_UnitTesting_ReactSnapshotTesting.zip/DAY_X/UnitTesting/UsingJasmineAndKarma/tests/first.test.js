describe("writting first test", () => {
  it("first test", () => {
    expect(true).toBe(true);
  });
});

function Add(x, y) {
  return x + y;
}

describe("test suite for addition", () => {
  it("should add two numbers", () => {
    expect(Add(20, 30)).toEqual(50);
  });
});
