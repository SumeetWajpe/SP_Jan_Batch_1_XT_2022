function GetData(callback) {
  // make the AJAX request
  // 1. XMLHttpRequest Object
  //2. Configure the xmlhttpreq open()
  //3. Send a request (async) -> send()
  //4. Check if data received !
  //  window.XMLHttpRequest -> check for the support
  var xmlhttpreq = new XMLHttpRequest();
  xmlhttpreq.open("GET", "https://jsonplaceholder.typicode.com/posts");
  xmlhttpreq.send(); // places an async call !
  xmlhttpreq.onreadystatechange = function () {
    if (xmlhttpreq.readyState === 4 && xmlhttpreq.status === 200) {
      callback(null, xmlhttpreq.responseText);
    } else if (xmlhttpreq.readyState === 4 && xmlhttpreq.status !== 200) {
      callback("Something went wrong ! " + xmlhttpreq.status, null);
    }
  };
}
