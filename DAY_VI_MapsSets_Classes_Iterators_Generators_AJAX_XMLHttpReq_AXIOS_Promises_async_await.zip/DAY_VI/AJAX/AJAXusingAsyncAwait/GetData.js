function GetData() {
  return new Promise(function (resolve, reject) {
    var xmlhttpreq = new XMLHttpRequest();
    xmlhttpreq.open("GET", "https://jsonplaceholder.typicode.com/posts");
    xmlhttpreq.send(); // places an async call !
    xmlhttpreq.onreadystatechange = function () {
      if (xmlhttpreq.readyState === 4 && xmlhttpreq.status === 200) {
        resolve(xmlhttpreq.responseText);
      } else if (xmlhttpreq.readyState === 4 && xmlhttpreq.status !== 200) {
        reject(xmlhttpreq.status);
      }
    };
  });
}
