// import { Add, Product as Multiply } from "./Math.js";
// // console.log("The addition is : " + Add(20, 30));
// console.log("The product is : " + Multiply(20, 30));

// import Addition from "./Math.js";
// console.log("The addition is : " + Addition(20, 40));

import * as MathModule from "./Math.js";
console.log("The product is ", MathModule.Product(20, 30));
