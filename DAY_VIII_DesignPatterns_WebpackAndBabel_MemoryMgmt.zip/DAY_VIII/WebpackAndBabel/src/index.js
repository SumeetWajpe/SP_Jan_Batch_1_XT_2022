import { Add, Point } from "./module";

console.log("The addition is : ", Add(20, 30));

var point = new Point(10, 20);
console.log(`Point : [${point.x},${point.y}]`);
