export var Add = (x, y) => x + y;

export class Point {
  constructor(x, y, z) {
    this.x = x;
    this.y = y;
  }
}
