class HelloWorld extends HTMLElement {
  constructor() {
    super();
    console.log("Hello Web Component !");
  }
}

customElements.define("uc-helloworld", HelloWorld);
