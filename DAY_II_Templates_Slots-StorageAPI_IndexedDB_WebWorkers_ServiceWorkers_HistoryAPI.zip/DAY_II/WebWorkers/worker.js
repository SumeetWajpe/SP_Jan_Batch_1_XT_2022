var largeArray = [];
console.log(this);
// 1. No access to window / document object
// 2. No access to localStorage/sessionStorage
// 3. No access to global variables (from UI thread)
// 4. But access to indexedDB / XMLHttpRequest / fetch

onmessage = function (msgFromUIThread) {
  console.log(msgFromUIThread.data);
  for (let i = 0; i < 5000; i++) {
    largeArray[i] = [];
    for (let j = 0; j < 8000; j++) {
      largeArray[i][j] = Math.random();
    }
  }
  postMessage(largeArray[2000][2000]);
  largeArray = null;// memory released
};
